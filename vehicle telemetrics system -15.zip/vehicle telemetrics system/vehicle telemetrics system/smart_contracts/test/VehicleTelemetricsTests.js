const Web3 = require('web3');
const { assert } = require('chai');
const { abi: contractABI } = require('./build/contracts/VehicleTelemetrics.json');
const contractAddress = '0x591D8c585558b2cCa052A9B8e042d3EffA379deA';

const web3 = new Web3('http://127.0.0.1:9545/');

const VehicleTelemetrics = new web3.eth.Contract(contractABI, contractAddress);

let accounts;
let owner;
let otherAccount;

before(async () => {
    accounts = await web3.eth.getAccounts();
    owner = accounts[0];
    otherAccount = accounts[1];
});

describe('VehicleTelemetrics Contract', () => {
    let vehicleId1;
    let vehicleId2;

    it('should add the first vehicle successfully', async () => {
        const receipt = await VehicleTelemetrics.methods.addVehicle(
            "ABC123",
            "Toyota",
            "Corolla",
            "Sedan",
            web3.utils.toWei('10', 'ether'),
            true,
            10000,
            15
        ).send({ from: owner });

        assert(receipt.status, true);
        vehicleId1 = await VehicleTelemetrics.methods.vehicleCount().call();
    });

    it('should add the second vehicle successfully', async () => {
        const receipt = await VehicleTelemetrics.methods.addVehicle(
            "DEF456",
            "Honda",
            "Civic",
            "Sedan",
            web3.utils.toWei('12', 'ether'),
            true,
            15000,
            20
        ).send({ from: owner });

        assert(receipt.status, true);
        vehicleId2 = await VehicleTelemetrics.methods.vehicleCount().call();
    });

    it('should fail to add telemetric data with invalid timestamps', async () => {
        try {
            await VehicleTelemetrics.methods.addTelemetricData(
                vehicleId1,
                1622592000,
                1622505600,
                60,
                80
            ).send({ from: owner });
            assert.fail("Expected error not received");
        } catch (error) {
            assert.include(error.message, "Invalid timestamps");
        }
    });

    it('should add telemetric data successfully for the first vehicle', async () => {
        const receipt = await VehicleTelemetrics.methods.addTelemetricData(
            vehicleId1,
            1622505600,
            1622592000,
            60,
            80
        ).send({ from: owner });

        assert(receipt.status, true);
    });

    it('should fail to set first vehicle for sale by non-owner', async () => {
        try {
            await VehicleTelemetrics.methods.setForSale(vehicleId1, false).send({ from: otherAccount });
            assert.fail("Expected error not received");
        } catch (error) {
            assert.include(error.message, "Only the owner can perform this action");
        }
    });

    it('should set first vehicle for sale successfully', async () => {
        const receipt = await VehicleTelemetrics.methods.setForSale(vehicleId1, false).send({ from: owner });
        assert(receipt.status, true);
    });

    it('should fail to buy a non-for-sale vehicle', async () => {
        try {
            await VehicleTelemetrics.methods.buyVehicle(vehicleId1).send({
                from: otherAccount,
                value: web3.utils.toWei('10', 'ether')
            });
            assert.fail("Expected error not received");
        } catch (error) {
            assert.include(error.message, "Vehicle is not for sale");
        }
    });

    it('should set first vehicle for sale again successfully', async () => {
        const receipt = await VehicleTelemetrics.methods.setForSale(vehicleId1, true).send({ from: owner });
        assert(receipt.status, true);
    });

    it('should fail to buy first vehicle with insufficient payment', async () => {
        try {
            await VehicleTelemetrics.methods.buyVehicle(vehicleId1).send({
                from: otherAccount,
                value: web3.utils.toWei('5', 'ether')
            });
            assert.fail("Expected error not received");
        } catch (error) {
            assert.include(error.message, "Invalid payment");
        }
    });

    it('should buy first vehicle successfully', async () => {
        const receipt = await VehicleTelemetrics.methods.buyVehicle(vehicleId1).send({
            from: otherAccount,
            value: web3.utils.toWei('10', 'ether')
        });

        assert(receipt.status, true);
        const newOwner = await VehicleTelemetrics.methods.vehicles(vehicleId1).call();
        assert.equal(newOwner.owner, otherAccount);
    });

    it('should return the vehicles by the new owner address', async () => {
        const vehicles = await VehicleTelemetrics.methods.getVehiclesByOwnerAddress(otherAccount).call();
        assert.equal(vehicles.length, 1);
        assert.equal(vehicles[0].id, vehicleId1);
    });

    it('should return for sale vehicles', async () => {
        const forSaleVehicles = await VehicleTelemetrics.methods.getForSaleVehicles().call();
        assert(forSaleVehicles.length > 0);
    });

    it('should return all vehicles', async () => {
        const allVehicles = await VehicleTelemetrics.methods.getAllVehicles().call();
        assert(allVehicles.length > 0);
    });

    it('should add telemetric data successfully for the second vehicle', async () => {
        const receipt = await VehicleTelemetrics.methods.addTelemetricData(
            vehicleId2,
            1622505600,
            1622592000,
            70,
            90
        ).send({ from: owner });

        assert(receipt.status, true);
    });

    it('should set second vehicle for sale successfully', async () => {
        const receipt = await VehicleTelemetrics.methods.setForSale(vehicleId2, true).send({ from: owner });
        assert(receipt.status, true);
    });

    it('should fail to buy second vehicle with zero payment', async () => {
        try {
            await VehicleTelemetrics.methods.buyVehicle(vehicleId2).send({
                from: otherAccount,
                value: 0
            });
            assert.fail("Expected error not received");
        } catch (error) {
            assert.include(error.message, "Invalid payment");
        }
    });

    it('should buy second vehicle successfully', async () => {
        const receipt = await VehicleTelemetrics.methods.buyVehicle(vehicleId2).send({
            from: otherAccount,
            value: web3.utils.toWei('12', 'ether')
        });

        assert(receipt.status, true);
        const newOwner = await VehicleTelemetrics.methods.vehicles(vehicleId2).call();
        assert.equal(newOwner.owner, otherAccount);
    });

    it('should return the vehicles by the original owner address', async () => {
        const vehicles = await VehicleTelemetrics.methods.getVehiclesByOwnerAddress(owner).call();
        assert.equal(vehicles.length, 0);
    });

    it('should return the total number of vehicles', async () => {
        const allVehicles = await VehicleTelemetrics.methods.getAllVehicles().call();
        assert.equal(allVehicles.length, 2);
    });
});